import confetti from 'canvas-confetti';

// Simple confetti effect on button click
const applyButton = document.getElementById('apply-button');

if (applyButton) {
    applyButton.addEventListener('click', () => {
        confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
        });
    });
}

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        // Exclude modal-related links and simple '#' placeholders from smooth scroll
        if (href === '#' || 
            this.id === 'login-modal-button' || 
            this.classList.contains('show-login-link') ||
            this.id === 'show-reg-type-link' ||
            this.id === 'switch-to-merchant-reg-link' ||
            this.id === 'switch-to-customer-reg-link' ||
            this.closest('.modal-switch a')) { // Catches old links if any remain, or general modal internal links
            e.preventDefault(); // Prevent jump for these specific links
            return; // JS will handle these
        }

        if (href && href.length > 1) {
            try {
                const targetElement = document.querySelector(href);
                if (targetElement) {
                    e.preventDefault();
                    targetElement.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            } catch (error) {
                // Handle invalid selector error if href is not a valid ID/selector
                console.warn('Smooth scroll target not found or invalid:', href, error);
            }
        }
    });
});

// Modal functionality
const loginModal = document.getElementById('login-modal');
const loginModalButton = document.getElementById('login-modal-button');
const closeButton = document.querySelector('.modal .close-button');
const modalTitle = document.getElementById('modal-title');

// Forms and sections
const loginForm = document.getElementById('login-form');
const registrationTypeSelection = document.getElementById('registration-type-selection');
const customerRegisterForm = document.getElementById('customer-register-form');
const merchantRegisterForm = document.getElementById('merchant-register-form');

// Buttons for switching views
const showRegTypeLink = document.getElementById('show-reg-type-link');
const registerAsCustomerBtn = document.getElementById('register-as-customer-btn');
const registerAsMerchantBtn = document.getElementById('register-as-merchant-btn');
const switchToMerchantRegLink = document.getElementById('switch-to-merchant-reg-link');
const switchToCustomerRegLink = document.getElementById('switch-to-customer-reg-link');
const showLoginLinks = document.querySelectorAll('.show-login-link');


function showModalSection(sectionToShow) {
    loginForm.style.display = 'none';
    registrationTypeSelection.style.display = 'none';
    customerRegisterForm.style.display = 'none';
    merchantRegisterForm.style.display = 'none';

    if (sectionToShow) {
        sectionToShow.style.display = 'block'; // Or 'flex' if it's a flex container like the modal itself
    }

    // Update modal title based on active section
    if (sectionToShow === loginForm) {
        modalTitle.textContent = 'Ingresar';
    } else if (sectionToShow === registrationTypeSelection) {
        modalTitle.textContent = 'Selecciona tu tipo de registro';
    } else if (sectionToShow === customerRegisterForm) {
        modalTitle.textContent = 'Registro de Cliente';
    } else if (sectionToShow === merchantRegisterForm) {
        modalTitle.textContent = 'Registro de Comercio';
    } else {
        modalTitle.textContent = 'Ingresar o Registrarse'; // Default
    }
}


if (loginModalButton) {
    loginModalButton.addEventListener('click', (e) => {
        e.preventDefault();
        loginModal.style.display = 'flex';
        showModalSection(loginForm); // Show login form by default
    });
}

if (closeButton) {
    closeButton.addEventListener('click', () => {
        loginModal.style.display = 'none';
    });
}

window.addEventListener('click', (event) => {
    if (event.target === loginModal) {
        loginModal.style.display = 'none';
    }
});

// Navigation within modal
if (showRegTypeLink) {
    showRegTypeLink.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(registrationTypeSelection);
    });
}

showLoginLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(loginForm);
    });
});

if (registerAsCustomerBtn) {
    registerAsCustomerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(customerRegisterForm);
    });
}

if (registerAsMerchantBtn) {
    registerAsMerchantBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(merchantRegisterForm);
    });
}

if (switchToMerchantRegLink) {
    switchToMerchantRegLink.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(merchantRegisterForm);
    });
}

if (switchToCustomerRegLink) {
    switchToCustomerRegLink.addEventListener('click', (e) => {
        e.preventDefault();
        showModalSection(customerRegisterForm);
    });
}


// Form Submissions
if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        if (email && password) {
            alert('Ingreso exitoso (simulado)');
            loginModal.style.display = 'none';
            loginForm.reset();
        } else {
            alert('Por favor, completa todos los campos.');
        }
    });
}

if (customerRegisterForm) {
    customerRegisterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const fullName = document.getElementById('reg-customer-fullname').value;
        const alias = document.getElementById('reg-customer-alias').value;
        const idNumber = document.getElementById('reg-customer-id').value;
        const phone = document.getElementById('reg-customer-phone').value;
        const email = document.getElementById('reg-customer-email').value;
        const password = document.getElementById('reg-customer-password').value;
        const confirmPassword = document.getElementById('reg-customer-confirm-password').value;

        if (fullName && alias && idNumber && phone && email && password && confirmPassword) {
            if (password === confirmPassword) {
                alert('Registro de cliente exitoso (simulado)');
                loginModal.style.display = 'none';
                customerRegisterForm.reset();
                showModalSection(loginForm); // Go back to login form
            } else {
                alert('Las contraseñas no coinciden.');
            }
        } else {
            alert('Por favor, completa todos los campos.');
        }
    });
}

if (merchantRegisterForm) {
    merchantRegisterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const storeName = document.getElementById('reg-merchant-name').value;
        const storeRif = document.getElementById('reg-merchant-rif').value;
        const storeCategory = document.getElementById('reg-merchant-category').value;
        const storeAddress = document.getElementById('reg-merchant-address').value;
        const contactPerson = document.getElementById('reg-merchant-contact-person').value;
        const phone = document.getElementById('reg-merchant-phone').value;
        const email = document.getElementById('reg-merchant-email').value;
        const password = document.getElementById('reg-merchant-password').value;
        const confirmPassword = document.getElementById('reg-merchant-confirm-password').value;

        if (storeName && storeRif && storeCategory && storeAddress && contactPerson && phone && email && password && confirmPassword) {
            if (password === confirmPassword) {
                alert('Registro de comercio exitoso (simulado)');
                loginModal.style.display = 'none';
                merchantRegisterForm.reset();
                showModalSection(loginForm); // Go back to login form
            } else {
                alert('Las contraseñas no coinciden.');
            }
        } else {
            alert('Por favor, completa todos los campos del comercio.');
        }
    });
}

console.log("xPagar script loaded and updated for new registration flow.");